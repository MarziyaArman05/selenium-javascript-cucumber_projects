const { Given, When, Then } = require("@cucumber/cucumber");
const { By } = require("selenium-webdriver");
const until = require("selenium-webdriver/lib/until");

Then(
  "I should see the Specialities text on the left side of the page",
  { timeout: 60 * 1000 },
  async function () {
    await driver.wait(
      until.elementLocated(
        By.xpath(".//span[contains(text(),'Specialities')]")
      ),
      10000
    );
    await driver.findElement(
      By.xpath(".//span[contains(text(),'Specialities')]")
    );
  }
);

When(
  "I click on the Specialities text",
  { timeout: 60 * 1000 },
  async function () {
    await driver.wait(
      until.elementLocated(
        By.xpath(".//span[contains(text(),'Specialities')]")
      ),
      10000
    );
    await driver
      .findElement(By.xpath(".//span[contains(text(),'Specialities')]"))
      .click();
  }
);
Then(
  "I should see the 20+ Specialities heading on the page",
  { timeout: 60 * 1000 },
  async function () {
    await driver.wait(
      until.elementLocated(
        By.css("h2.MuiTypography-root.jss4.MuiTypography-h6")
      ),
      10000
    );
    await driver.findElement(
      By.css("h2.MuiTypography-root.jss4.MuiTypography-h6")
    );
  }
);
Then(
  "I should see the search bar on the right side of the page",
  async function () {
    await driver
      .findElement(
        By.className(
          "MuiInputBase-input MuiOutlinedInput-input MuiInputBase-inputAdornedEnd MuiOutlinedInput-inputAdornedEnd MuiInputBase-inputMarginDense MuiOutlinedInput-inputMarginDense"
        )
      )
      .isDisplayed();
  }
);
