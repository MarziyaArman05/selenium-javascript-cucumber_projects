const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By, by, Key, Builder, WebElement } = require("selenium-webdriver");
const { expect } = require("chai");
const { setDefaultTimeout } = require("@cucumber/cucumber");
const { initDriver } = require("../support/driverUtil");
setDefaultTimeout(60 * 1000);

const chrome = require("chromedriver");

const firefox = require("selenium-webdriver/firefox");

let driver;

Before(function () {
  console.log("inside Before");
  driver = initDriver();
  driver.manage().window().maximize();
});
After(function () {
  console.log("inside After");
  //   driver.quit();
});

Given("I am on the MyDoctor homepage", function () {
  driver.get("https://mydoctorportal.herokuapp.com/");
});

Then("I should see the login button on the header", function () {
  driver.findElement(By.className("MuiTouchRipple-root")).getText();
});
When("I click on the login button on the header", async function () {
  await driver
    .findElement(
      By.className(
        "MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-disableElevation"
      )
    )
    .click();
});
Then("I should see the login tab on the page", async function () {
  await driver.findElement(By.css("form#login"));
});

When("I fill the email or Mobile number on the input field", async function () {
  await driver
    .findElement(By.css("input#emailOrMobile"))
    .sendKeys("mytestdata01@gmai.lcom");
});
Then("I fill the password on the input field", async function () {
  await driver.findElement(By.css("input#password")).sendKeys("Testdata@123");
});
When("I click on the submit button", async function () {
  await driver.findElement(By.css("div.jss19 > button[type=submit]")).click();
});
