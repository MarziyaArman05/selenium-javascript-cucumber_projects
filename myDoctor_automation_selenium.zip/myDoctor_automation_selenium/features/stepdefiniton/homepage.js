const { Given, Then, When, Before, After } = require("@cucumber/cucumber");

const {
  By, until} = require("selenium-webdriver");
const assert = require("assert");

Then("I should see the header of the home page", async function () {
  await driver
    .findElement(
      By.className("MuiToolbar-root MuiToolbar-regular jss9 MuiToolbar-gutters")
    )
    .isDisplayed();
});

Then("I should see the search bar on the header", async function () {
  await driver
    .findElement(
      By.className("MuiPaper-root jss13 MuiPaper-elevation0 MuiPaper-rounded")
    )
    .isDisplayed();
});

Then("I should see the image on the page", async function () {
  await driver.findElement(By.tagName("img")).getAttribute("alt");
});

When("I scroll down the page", { timeout: 60 * 1000 }, async function () {
  await driver.wait(
    until.elementLocated(By.css("nav.MuiPagination-root.jss5")),
    10000
  );
  const scrollpage = await driver.findElement(
    By.css("nav.MuiPagination-root.jss5")
  );

  await driver.actions().scroll(0, 0, 0, 0, scrollpage).perform();
});
Then(
  "I should see the pagination button on the bottom of the homepage",
  { timeout: 60 * 1000 },
  async function () {
    await driver.wait(
      until.elementLocated(By.css("nav.MuiPagination-root.jss5")),
      10000
    );
    await driver
      .findElement(By.css("nav.MuiPagination-root.jss5"))
      .isDisplayed();
  }
);
Then("I should see Previous pagination button", async function () {
  await driver.findElement(By.css("ul.MuiPagination-ul li"));
});
Then("I should see Next pagination button", async function () {
  await driver.findElement(By.css("ul.MuiPagination-ul li"));
});
Then("I should see pagination 1 as active", async function () {
  await driver.findElement(By.css("ul.MuiPagination-ul"));
});

When("I click pagination 2", async function () {
  await driver.findElement(By.xpath(".//button[contains(text(),'2')]")).click();
});
Then("I should see pagination 2 as active on the page", async function () {
  await driver.findElement(By.xpath(".//button[contains(text(),'2')]"));
});
