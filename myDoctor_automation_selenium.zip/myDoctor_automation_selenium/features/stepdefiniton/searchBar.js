const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By, by, Key, Builder, WebElement } = require("selenium-webdriver");
const until = require("selenium-webdriver/lib/until");
Then(
  "I select the service in the service input field dropdown",
  { timeout: 60 * 1000 },
  async function () {
    await driver.wait(
      until.elementLocated(By.css('input[placeholder="Select a Service"]')),
      10000
    );
    await driver
      .findElement(By.css('input[placeholder="Select a Service"]'))
      .click();

    await driver
      .findElement(By.css('input[placeholder="Select a Service"]'))
      .sendKeys("Dermatology");
    await driver.manage().setTimeouts({ implicit: 10000 });

    await driver
      .findElement(By.css('input[placeholder="Select a Service"]'))
      .sendKeys(Key.DOWN, Key.RETURN);
  }
);


When(
  "I fill doctor name in the search input field",
  { timeout: 60 * 1000 },
  async function () {
    await driver
      .findElement(By.xpath('.//input[@placeholder="Search Doctors"]'))
      .sendKeys("Dr. Monserrate Kihn");
  }
);
When("I click the search bar icon", async function () {
  await driver
    .findElement(
      By.xpath('.//button[@class="MuiButtonBase-root MuiIconButton-root"]')
    )
    .click();
});
Then("I should see the doctor details", async function () {
  //   await driver
  //     .findElement(By.css("h6.MuiTypography-root.MuiTypography-h6"))
  //     .isDisplayed();
});
