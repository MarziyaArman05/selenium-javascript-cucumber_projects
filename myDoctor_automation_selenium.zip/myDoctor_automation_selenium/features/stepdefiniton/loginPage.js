const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By, by, Key, Builder, WebElement } = require("selenium-webdriver");


Then(
  "I should see login successfully message on the screen",
  async function () {
    await driver.findElement(By.css("input#password"));
  }
);
Then(
  "I should see login, patient sign up and doctor sign up tabs",
  async function () {
    await driver.findElement(By.css("div.MuiTabs-flexContainer"));
  }
);
