const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By, by, Key, Builder, WebElement } = require("selenium-webdriver");

When("I click on the login button", async function () {
  await driver
    .findElement(
      By.className(
        "MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-disableElevation"
      )
    )
    .click();
});
Then("I should see the login tab", async function () {
  await driver.findElement(
    By.className(
      "MuiGrid-root MuiGrid-item MuiGrid-justify-content-xs-center MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-6 MuiGrid-grid-lg-4 MuiGrid-grid-xl-4"
    )
  );
});

When(
  "I click on the doctor sign up tab",
  { timeout: 60 * 1000 },
  async function () {
    await driver
      .findElement(
        By.className(
          "MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected MuiTab-fullWidth"
        )
      )
      .click();
  }
);
Then(
  "I should see the doctor sign up tab",
  { timeout: 60 * 1000 },
  async function () {
    await driver.findElement(
      By.className("MuiPaper-root MuiPaper-outlined MuiPaper-rounded")
    );
  }
);
Then(
  "I should see the full name input field on the tab",
  { timeout: 60 * 1000 },
  async function () {
    await driver.findElement(By.css("input#full_name")).isDisplayed();
  }
);
