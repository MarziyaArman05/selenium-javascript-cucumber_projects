const { Given, When, Then } = require("@cucumber/cucumber");
const { By, Key, WebElement } = require("selenium-webdriver");
const until = require("selenium-webdriver/lib/until");
Then("I should be navigated to the doctor homepage", async function () {
  await driver.findElement(By.id("root"));
});

Then(
  "I should see the Doctor Profile button on the life side of the page",
  async function () {

  }
);
When("I click on the doctor profile button", async function () {
  console.log("first");

  await driver.wait(
    until.elementLocated(
      By.xpath(".//span[contains(text(),'Doctor Profile')]")
    ),
    10000
  );
  let text = await driver
    .findElement(By.xpath(".//span[contains(text(),'Doctor Profile')]"))
    .click();
});

Then("I should see the My Profile text on the page", async function () {
  await driver.wait(
    until.elementLocated(
      By.className(
        "MuiTypography-root jss4 MuiTypography-body1 MuiTypography-colorPrimary"
      )
    ),
    10000
  );
  await driver
    .findElement(
      By.className(
        "MuiTypography-root jss4 MuiTypography-body1 MuiTypography-colorPrimary"
      )
    )
    .isDisplayed();
});

Then("I should see the profile image on the page", async function () {
  await driver.findElement(
    By.className(
      "MuiAvatar-root MuiAvatar-circular jss5 MuiAvatar-colorDefault"
    )
  );
});
Then("I should see the doctor details on the page", async function () {
  await driver.findElement(
    By.className("MuiPaper-root MuiPaper-outlined MuiPaper-rounded")
  );
});

Then(
  "I should see the Dashboard button on the life side of the page",
  { timeout: 60 * 1000 },
  async function () {
    await driver.wait(
      until.elementLocated(By.xpath(".//span[contains(text(),'Dashboard')]")),
      10000
    );
    await driver.findElement(By.xpath(".//span[contains(text(),'Dashboard')]"));
  }
);

Then(
  "I should see the Appointments button on the life side of the page",
  { timeout: 60 * 1000 },
  async function () {
    await driver.findElement(
      By.xpath(".//span[contains(text(),'Appointments')]")
    );
  }
);
Then(
  "I should see the Reviews button on the life side of the page",
  { timeout: 60 * 1000 },
  async function () {
    await driver.findElement(By.xpath(".//span[contains(text(),'Reviews')]"));
  }
);
